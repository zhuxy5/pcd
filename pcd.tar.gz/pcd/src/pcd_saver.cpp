#include <ros/ros.h>
#include <stdio.h>
#include <octomap/octomap.h>
#include <octomap/OcTree.h>
#include <octomap/OcTreeBase.h>
#include "pcl/io/pcd_io.h"
#include "pcl/point_types.h"
#include "converter.h"
#include <iostream>
#include <fstream>
#include <octomap/AbstractOcTree.h>
#include <octomap/AbstractOccupancyOcTree.h>
#include <math.h>
#include <fstream>

using namespace std;
using namespace octomap;


void Converter::pcd2obj(const std::string& inputFilename, const std::string& outputFilename)
{
    pcl::PointCloud<pcl::PointXYZ> cloud;

    if (pcl::io::loadPCDFile<pcl::PointXYZ> (inputFilename, cloud) == -1)
    {
        std::cerr << "Couldn't read file " << inputFilename << std::endl;
        return;
    }

    const size_t size = cloud.points.size();
    std::ofstream os(outputFilename.c_str());

    for(unsigned int i=0 ; i<size ; i++)
    {
        // Remove nan
        if(!std::isnan(cloud.points[i].x))
        {
            os << "v ";
            os << cloud.points[i].x << " ";
            os << cloud.points[i].y << " ";
            os << cloud.points[i].z << "\n";
        }
    }

    os.close();
}


void Converter::obj2pcd(const std::string& inputFilename, const std::string& outputFilename)
{
    pcl::PointCloud<pcl::PointXYZ> cloud;

    // Input stream
    std::ifstream is(inputFilename.c_str());

    // Read line by line
    for(std::string line; std::getline(is, line); )
    {
        std::istringstream in(line);

        std::string v;
        in >> v;
        if (v != "v") continue;

        // Read x y z
        float x, y, z;
        in >> x >> y >> z;
        cloud.push_back(pcl::PointXYZ(x, y, z));
    }

    is.close();

    // Save to pcd file
    pcl::io::savePCDFileBinaryCompressed(outputFilename, cloud);
}



int main(int argc, char* argv[])
{
  // This must be called before anything else ROS-related
  ros::init(argc, argv, "pcd");

  // Create a ROS node handle
    ros::NodeHandle node;
string file ="/home/zhuxy/catkin_ws/src/pcd/src/map.ot";
  int i=0;
  pcl::PointCloud<pcl::PointXYZ> cloud; 
  AbstractOcTree* tree = AbstractOcTree::read(file);
  OcTree* octree = dynamic_cast<OcTree*>(tree);
  if (tree!=NULL){
    ROS_INFO("Not NULL");
  }
//  cloud = new pcl::PointCloud<pcl::PointXYZ>();
 int len= int(sqrt(octree->calcNumNodes()));
 cloud.width  = len;
  cloud.height = len;
  cloud.points.resize (cloud.width * cloud.height);

  //cloud.points.resize (octree->calcNumNodes());
      for(OcTree::leaf_iterator it = octree->begin_leafs(),
          end=octree->end_leafs(); it!= end; ++it, i++)
  {
    //add point in point cloud
  //ROS_INFO("Hello, World!");
  //  string ret= string(it.getX());
//    ROS_INFO("%.15g \n", it.getX()) ;
    //std::cout << "Node center: " << it.getX() << std::endl;
    
              cloud.points[i].x = it.getX();
              cloud.points[i].y = it.getY();
               cloud.points[i].z = it.getZ();  
            //    ROS_INFO("Hello, World!");

  }
 ROS_INFO("Hello, World!");

pcl::io::savePCDFileASCII ("/home/zhuxy/catkin_ws/src/pcd/src/file.pcd", cloud);
Converter::pcd2obj("/home/zhuxy/catkin_ws/src/pcd/src/file.pcd", "output.obj");
}
